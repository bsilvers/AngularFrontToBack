export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAB8N5Bi22whQg6FHziM6cl5Q4-fL9MLb8",
    authDomain: "clientpanelprod.firebaseapp.com",
    databaseURL: "https://clientpanelprod.firebaseio.com",
    projectId: "clientpanelprod",
    storageBucket: "clientpanelprod.appspot.com",
    messagingSenderId: "818661613185"
  }
};
